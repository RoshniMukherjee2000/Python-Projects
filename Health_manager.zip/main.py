# main.py
from health_manager import log_data, retrieve_data
from users import USERS

# Main Program

def main():
    print("\n===== Health Management System =====\n")

    # Show users list
    print("Select User:")
    for key, name in USERS.items():
        print(f"{key}. {name}")

    try:
        user_choice = int(input("\nEnter user number: "))

        if user_choice not in USERS:
            print("Invalid user selection!")
            return

        print("\n1. Log Exercise")
        print("2. Log Diet")
        print("3. Retrieve Exercise Log")
        print("4. Retrieve Diet Log")

        action = int(input("Enter your choice: "))

        if action == 1:
            log_data(user_choice, "exercise")
        elif action == 2:
            log_data(user_choice, "diet")
        elif action == 3:
            retrieve_data(user_choice, "exercise")
        elif action == 4:
            retrieve_data(user_choice, "diet")
        else:
            print("Invalid option!")

    except ValueError:
        print("Please enter numeric input only!")

if __name__ == "__main__":
    while True:
        main()
        again = input("Do you want to continue? (y/n): ").lower()
        if again != 'y':
            print("\nThank you for using the Health Management System!")
            break
