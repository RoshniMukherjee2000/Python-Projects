# users.py

# List of users in the Health Management System
USERS = {
    1: "Roshni",
    2: "Amit",
    3: "Priya"
}
