# health_manager.py
from datetime import datetime
from users import USERS


# Function to get current timestamp

def get_time():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# Function to create filename based on user and activity

def get_filename(user, activity):
    return f"{USERS[user]}_{activity}.txt"


# Function to log diet/exercise data

def log_data(user, activity):
    filename = get_filename(user, activity)
    entry = input(f"Enter {activity} details: ")

    with open(filename, "a") as file:
        file.write(f"[{get_time()}] - {entry}\n")

    print(f"Successfully logged {activity} for {USERS[user]}!\n")


# Function to retrieve stored data

def retrieve_data(user, activity):
    filename = get_filename(user, activity)

    try:
        with open(filename, "r") as file:
            data = file.read()

        print(f"\n {USERS[user]}'s {activity.capitalize()} Log:")
        print("---------------------------------------")
        print(data if data else "No records found.")
        print("---------------------------------------\n")

    except FileNotFoundError:
        print("\n No log file found! No data recorded yet.\n")
