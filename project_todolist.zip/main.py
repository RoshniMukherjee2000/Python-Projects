from todo import ToDoApp

app = ToDoApp()

while True:
    print("\n---- TO DO MENU ----")
    print("1. Add Task")
    print("2. Remove Task")
    print("3. Show Tasks")
    print("4. Exit")

    choice = input("Enter choice: ")

    if choice == "1":
        task = input("Enter task: ")
        app.add_task(task)

    elif choice == "2":
        task = input("Enter task to remove: ")
        app.remove_task(task)

    elif choice == "3":
        app.show_tasks()

    elif choice == "4":
        print("Exiting...")
        break

    else:
        print("Invalid choice! Try again.")
