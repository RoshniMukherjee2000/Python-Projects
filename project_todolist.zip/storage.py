import os

class Storage:
    FILE_NAME = "tasks.txt"

    @staticmethod
    def load_tasks():
        """Load tasks from file and return a list"""
        if not os.path.exists(Storage.FILE_NAME):
            return []

        with open(Storage.FILE_NAME, "r") as file:
            tasks = [line.strip() for line in file.readlines()]
        return tasks

    @staticmethod
    def save_tasks(tasks):
        """Save the list of tasks into the file"""
        with open(Storage.FILE_NAME, "w") as file:
            for task in tasks:
                file.write(task + "\n")
