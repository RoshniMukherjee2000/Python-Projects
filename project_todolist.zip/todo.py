from storage import Storage

class ToDoApp:
    def __init__(self):
        self.tasks = Storage.load_tasks()

    def add_task(self, task):
        self.tasks.append(task)
        Storage.save_tasks(self.tasks)
        print(f"Task added: {task}")

    def remove_task(self, task):
        if task in self.tasks:
            self.tasks.remove(task)
            Storage.save_tasks(self.tasks)
            print(f"Task removed: {task}")
        else:
            print("Task not found!")

    def show_tasks(self):
        if not self.tasks:
            print("No tasks found.")
        else:
            print("\nYour Tasks:")
            for i, t in enumerate(self.tasks, 1):
                print(f"{i}. {t}")
